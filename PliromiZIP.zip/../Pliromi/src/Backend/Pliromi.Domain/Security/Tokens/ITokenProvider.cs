namespace Pliromi.Domain.Security.Tokens;

public interface ITokenProvider
{
	string Value();
}