namespace Pliromi.Domain.Repositories;

public interface IUnitOfWork
{
	Task Commit();
}