namespace Pliromi.Domain.Entities;

public class ReceiverDataForTransaction
{
	public string? ReceiverCpf { get; set; } 
	public string? ReceiverCnpj { get; set; } 
	public string? ReceiverEmail { get; set; } 
	
}