namespace Exceptions;

public static class PliromiLoginMessagesErrors
{
	public const string InvalidCredentials = "Invalid login credentials";
	
}